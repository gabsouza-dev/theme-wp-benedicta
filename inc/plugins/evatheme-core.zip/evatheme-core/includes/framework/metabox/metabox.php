<?php
/**
 * Page Settings Metabox
 * Developed & Designed exclusively for the Evatheme WordPress themes
 * Do not copy, re-sell or reproduce!
 *
 * @package Evatheme WordPress Themes
 * @subpackage Framework
 * @version 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The Metabox class
class evatheme_core_Post_Metaboxes {
	private $post_types;

	/**
	 * Register this class with the WordPress API
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Post types to add the metabox to
		$this->post_types = apply_filters( 'evatheme_core_main_metaboxes_post_types', array(
			'post'         => 'post',
			'page'         => 'page',
			'portfolio'    => 'portfolio',
			'product'      => 'product',
		) );

		// Loop through post types and add metabox to corresponding post types
		if ( $this->post_types ) {
			foreach( $this->post_types as $key => $val ) {
				add_action( 'add_meta_boxes_'. $val, array( $this, 'post_meta' ), 11 );
			}
		}

		// Save meta
		add_action( 'save_post', array( $this, 'save_meta_data' ) );

		// Load scripts for the metabox
		add_action( 'admin_enqueue_scripts', array( $this, 'load_scripts' ) );

	}

	/**
	 * The function responsible for creating the actual meta box.
	 *
	 * @since 1.0.0
	 */
	public function post_meta( $post ) {
		
		$obj = get_post_type_object( $post->post_type );
		
		// Add metabox
		add_meta_box(
			'evatheme_core-metabox',
			$obj->labels->singular_name . ' ' . esc_html__( 'Settings', 'ecatheme_core' ),
			array( $this, 'display_meta_box' ),
			$post->post_type,
			'normal',
			'high'
		);

	}

	/**
	 * Enqueue scripts and styles needed for the metaboxes
	 *
	 * @since 1.0.0
	 */
	public function load_scripts( $hook ) {

		// Only needed on these admin screens
		if ( $hook != 'edit.php' && $hook != 'post.php' && $hook != 'post-new.php' ) {
			return;
		}

		// Get global post
		global $post;

		// Return if post is not object
		if ( ! is_object( $post ) ) {
			return;
		}

		// Enqueue metabox css
		wp_enqueue_style( 'evatheme_core-post-metabox', plugin_dir_url( __FILE__ ) .'/evatheme_core-metabox.css', array(), '1.0' );

		// Enqueue media js
		wp_enqueue_media();

		// Enqueue color picker
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		// Enqueue metabox js
		wp_enqueue_script( 'evatheme_core-post-metabox', plugin_dir_url( __FILE__ ) .'/evatheme_core-metabox.js', array( 'jquery', 'wp-color-picker' ), '1.0', true );

		wp_localize_script( 'evatheme_core-post-metabox', 'evatheme_core_metabox', array(
			'reset'  => esc_html__(  'Reset Settings', 'ecatheme_core' ),
			'cancel' => esc_html__(  'Cancel Reset', 'ecatheme_core' ),
		) );

	}

	/**
	 * Renders the content of the meta box.
	 *
	 * @since 1.0.0
	 */
	public function display_meta_box( $post ) {

		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'evatheme_core_metabox', 'evatheme_core_metabox_nonce' );

		// Get current post data
		$post_id   = $post->ID;
		$post_type = get_post_type();

		// Get tabs
		$tabs = evatheme_core_meta_array( $post );

		// Empty notice
		$empty_notice = esc_html__( 'No meta settings available for this post type or user.', 'ecatheme_core' );

		// Make sure tabs aren't empty
		if ( empty( $tabs ) ) {
			echo '<p>'. esc_html( $empty_notice ) .'</p>'; return;
		}

		// Store tabs that should display on this specific page in an array for use later
		$active_tabs = array();
		foreach ( $tabs as $tab ) {
			$tab_post_type = isset( $tab['post_type'] ) ? $tab['post_type'] : '';
			if ( ! $tab_post_type ) {
				$display_tab = true;
			} elseif ( in_array( $post_type, $tab_post_type ) ) {
				$display_tab = true;
			} else {
				$display_tab = false;
			}
			if ( $display_tab ) {
				$active_tabs[] = $tab;
			}
		}

		// No active tabs
		if ( empty( $active_tabs ) ) {
			echo '<p>'. esc_html( $empty_notice ) .'</p>'; return;
		} ?>

		<ul class="wp-tab-bar">
			<?php
			// Output tab links
			$count=0;
			foreach ( $active_tabs as $tab ) {
				$count++;
				// Define tab title
				$tab_title = $tab['title'] ? $tab['title'] : esc_html__( 'Other', 'ecatheme_core' ); ?>
				<li<?php if ( '1' == $count ) echo ' class="wp-tab-active"'; ?>>
					<a href="javascript:;" data-tab="#evatheme_core-mb-tab-<?php echo esc_attr( $count ); ?>">
						<?php if ( isset( $tab['icon'] ) ) { ?>
							<span class="<?php echo esc_attr( $tab['icon'] ) ; ?>"></span>
						<?php } ?>
						<?php echo esc_html( $tab_title ); ?>
					</a>
				</li>
			<?php } ?>
		</ul><!-- .evatheme_core-mb-tabnav -->

		<?php
		// Output tab sections
		$count=0;
		foreach ( $active_tabs as $tab ) {
			$count++; ?>
			<div id="evatheme_core-mb-tab-<?php echo esc_attr( $count ); ?>" class="wp-tab-panel clr">
				<table class="form-table">
					<?php
					foreach ( $tab['settings'] as $setting ) {

						$meta_id     = $setting['id'];
						$title       = $setting['title'];
						$hidden      = isset( $setting['hidden'] ) ? $setting['hidden'] : false;
						$type        = isset( $setting['type'] ) ? $setting['type'] : 'text';
						$default     = isset( $setting['default'] ) ? $setting['default'] : '';
						$description = isset( $setting['description'] ) ? $setting['description'] : '';
						$meta_value  = get_post_meta( $post_id, $meta_id, true );
						$meta_value  = $meta_value ? $meta_value : $default; ?>

						<tr<?php if ( $hidden ) echo ' style="display:none;"'; ?> id="<?php echo esc_attr( $meta_id ); ?>_tr">
							<th>
								<label for="evatheme_core_main_layout"><strong><?php echo esc_html( $title ); ?></strong></label>
								<?php
								// Display field description
								if ( $description ) { ?>
									<p class="evatheme_core-mb-description"><?php echo esc_html( $description ); ?></p>
								<?php } ?>
							</th>

							<?php
							// Text Field
							if ( 'text' == $type ) { ?>

								<td><input name="<?php echo esc_attr( $meta_id ); ?>" type="text" value="<?php echo esc_attr( $meta_value ); ?>"></td>

							<?php
							}

							// Button Group
							if ( 'button_group' == $type ) {

								$options = isset ( $setting['options'] ) ? $setting['options'] : '';

								if ( is_array( $options ) ) { ?>

									<td>

										<div class="evatheme_core-mb-btn-group">

											<?php foreach ( $options as $option_value => $option_name ) {

												$class = 'evatheme_core-mb-btn evatheme_core-mb-' . esc_attr( $option_value );

												if ( $option_value == $meta_value ) {
													$class .= ' active';
												}  ?>

												<button type="button" class="<?php echo esc_attr( $class ); ?>" data-value="<?php echo esc_attr( $option_value ); ?>"><?php echo esc_html( $option_name ); ?></button>

											<?php } ?>

											<input name="<?php echo esc_attr( $meta_id ); ?>" type="hidden" value="<?php echo esc_attr( $meta_value ); ?>" class="evatheme_core-mb-hidden">

										</div>

									</td>

								<?php }

							}

							// Enable Disable button group
							if ( 'button_group_ed' == $type ) {

								$options = isset ( $setting['options'] ) ? $setting['options'] : '';

								if ( is_array( $options ) ) { ?>

									<td>

										<div class="evatheme_core-mb-btn-group">
											
											<?php
											// Default
											$active = ! $meta_value ? 'evatheme_core-mb-btn evatheme_core-default active' : 'evatheme_core-mb-btn evatheme_core-default'; ?>

											<button type="button" class="<?php echo esc_attr( $active ); ?>" data-value=""><?php echo esc_html_e( 'Default', 'ecatheme_core' ); ?></button>

											<?php
											// Enable
											$active = ( $options['enable'] == $meta_value ) ? 'evatheme_core-mb-btn evatheme_core-on active' : 'evatheme_core-mb-btn evatheme_core-on'; ?>

											<button type="button" class="<?php echo esc_attr( $active ); ?>" data-value="<?php echo esc_attr( $options['enable'] ); ?>"><?php echo esc_html_e( 'Enable', 'ecatheme_core' ); ?></button>

											<?php
											// Disable
											$active = ( $options['disable'] == $meta_value ) ? 'evatheme_core-mb-btn evatheme_core-off active' : 'evatheme_core-mb-btn evatheme_core-off'; ?>

											<button type="button" class="<?php echo esc_attr( $active ); ?>" data-value="<?php echo esc_attr( $options['disable'] ); ?>"><?php echo esc_html_e( 'Disable', 'ecatheme_core' ); ?></button>

											<input name="<?php echo esc_attr( $meta_id ); ?>" type="hidden" value="<?php echo esc_attr( $meta_value ); ?>" class="evatheme_core-mb-hidden">

										</div>

									</td>

								<?php }

							}

							// Number Field
							elseif ( 'number' == $type ) {

								$step = isset( $setting['step'] ) ? $setting['step'] : '1';
								$min  = isset( $setting['min'] ) ? $setting['min'] : '1';
								$max  = isset( $setting['max'] ) ? $setting['max'] : '10'; ?>

								<td>
									<input name="<?php echo esc_attr( $meta_id ); ?>" type="number" value="<?php echo esc_attr( $meta_value ); ?>" step="<?php echo floatval( $step ); ?>" min="<?php echo floatval( $min ); ?>" max="<?php echo floatval( $max ); ?>">
								</td>

							<?php }

							// Textarea Field
							elseif ( 'textarea' == $type ) {
								$rows = isset ( $setting['rows'] ) ? absint( $setting['rows'] ) : 4; ?>

								<td>
									<textarea rows="<?php echo esc_attr( $rows ); ?>" cols="1" name="<?php echo esc_attr( $meta_id ); ?>" type="text" class="evatheme_core-mb-textarea"><?php echo esc_textarea( $meta_value ); ?></textarea>
								</td>

							<?php }

							// Code Field
							elseif ( 'code' == $type ) {
								$rows = isset ( $setting['rows'] ) ? absint( $setting['rows'] ) : 1; ?>

								<td>
									<pre><textarea rows="<?php echo esc_attr( $rows ); ?>" cols="1" name="<?php echo esc_attr( $meta_id ); ?>" type="text" class="evatheme_core-mb-textarea-code"><?php echo apply_filters( "the_content", wp_specialchars_decode( $meta_value ) ); ?></textarea></pre>
								</td>

							<?php }

							// Checkbox
							elseif ( 'checkbox' == $type ) {

								$meta_value = ( 'on' != $meta_value ) ? false : true; ?>
								<td><input name="<?php echo esc_attr( $meta_id ); ?>" type="checkbox" <?php checked( $meta_value, true, true ); ?>></td>

							<?php }

							// Select
							elseif ( 'select' == $type ) {

								$options = isset ( $setting['options'] ) ? $setting['options'] : '';

								if ( ! empty( $options ) ) { ?>

									<td><select id="<?php echo esc_attr( $meta_id ); ?>" name="<?php echo esc_attr( $meta_id ); ?>">
									
									<?php foreach ( $options as $option_value => $option_name ) { ?>
										
										<option value="<?php echo esc_attr( $option_value ); ?>" <?php selected( $meta_value, $option_value, true ); ?>><?php echo esc_attr( $option_name ); ?></option>

									<?php } ?>

									</select></td>

								<?php }

							}

							// Color
							elseif ( 'color' == $type ) { ?>

								<td><input name="<?php echo esc_attr( $meta_id ); ?>" type="text" value="<?php echo esc_attr( $meta_value ); ?>" class="evatheme_core-mb-color-field"></td>

							<?php }
							
							//	Layout
							elseif ( 'layout' == $type ) { ?>
					
								<td class="metabox_type_layout">
									<?php  foreach ($setting['options'] as $val => $option) {
										echo '<a href="#" data-value="' . $val . '" ' . ( $val == $meta_value ? ' class="active"' : '' ) . '><img src="'.esc_url($option['img']).'">'.esc_html($option['title']).'</a>';
									} ?>
									<input name="<?php echo esc_attr( $meta_id ); ?>" type="hidden" value="<?php echo esc_attr( $meta_value ); ?>" />
								</td>

							<?php }
							
							// Media
							elseif ( 'media' == $type ) {

								// Validate data if array - old Redux cleanup
								if ( is_array( $meta_value ) ) {
									if ( ! empty( $meta_value['url'] ) ) {
										$meta_value = $meta_value['url'];
									} else {
										$meta_value = '';
									}
								} ?>
								<td>
									<div class="uploader">
									<input type="text" name="<?php echo esc_attr( $meta_id ); ?>" value="<?php echo esc_attr( $meta_value ); ?>">
									<input class="evatheme_core-mb-uploader button-secondary" name="<?php echo esc_attr( $meta_id ); ?>" type="button" value="<?php esc_html_e( 'Upload', 'ecatheme_core' ); ?>" />
									<?php if ( $meta_value ) {
											if ( is_numeric( $meta_value ) ) {
												$meta_value = wp_get_attachment_image_src( $meta_value, 'full' );
												$meta_value = $meta_value[0];
											} ?>
										<div class="evatheme_core-mb-thumb" style="padding-top:10px;"><img src="<?php echo esc_url( $meta_value ); ?>" height="40" width="" style="height:40px;width:auto;max-width:100%;" /></div>
									<?php } ?>
									</div>
								</td>

							<?php }
							
							// Gallery
							elseif ( 'gallery' == $type ) {

								?>
								<td>
									<div id="evatheme_core_gallery_images_container">
										<?php
											$gallery_thumbs = '';
											
											// Validate data if array - old Redux cleanup
											if ( is_array( $meta_value ) ) {
												if ( ! empty( $meta_value['url'] ) ) {
													$meta_value = $meta_value['url'];
												} else {
													$meta_value = '';
												}
											}
											
											if( $meta_value ) {
												$attachments = array_filter( explode( ',', $meta_value ) );
												foreach ( $attachments as $attachment_id ) {
													if ( wp_attachment_is_image ( $attachment_id  ) ) {
														$gallery_thumbs .= '<li class="image" data-attachment_id="' . $attachment_id . '"><div class="attachment-preview"><div class="thumbnail">
																	' . wp_get_attachment_image( $attachment_id, array(32,32) ) . '</div>
																	<a href="#" class="evatheme_core-gmb-remove" title="' . esc_attr__( 'Remove image', 'ecatheme_core' ) . '"><div class="media-modal-icon"></div></a>
																</div></li>';
													}
												}
											}
										?>
										<input type="hidden" id="image_gallery" name="<?php echo esc_attr( $meta_id ); ?>" value="<?php echo esc_attr( $meta_value ); ?>" />
										<?php wp_nonce_field( 'easy_image_gallery', 'easy_image_gallery' ); ?>
										<?php echo '<ul class="evatheme_core_gallery_images" style="font-size:0;margin-top:6px;">'. $gallery_thumbs .'</ul>'; ?>
									</div>
									<p class="add_evatheme_core_gallery_images hide-if-no-js">
										<a href="#" class="button-primary"><?php esc_html_e( 'Add/Edit Images', 'ecatheme_core' ); ?></a>
									</p>
								</td>

							<?php }

							// Editor
							elseif ( 'editor' == $type ) {
								$teeny= isset( $setting['teeny'] ) ? $setting['teeny'] : false;
								$rows = isset( $setting['rows'] ) ? $setting['rows'] : '10';
								$media_buttons= isset( $setting['media_buttons'] ) ? $setting['media_buttons'] : true; ?>
								<td><?php wp_editor( $meta_value, $meta_id, array(
									'textarea_name' => $meta_id,
									'teeny'         => $teeny,
									'textarea_rows' => $rows,
									'media_buttons' => $media_buttons,
								) ); ?></td>
							<?php } ?>
						</tr>

					<?php } ?>
				</table>
			</div>
		<?php } ?>

		<div class="evatheme_core-mb-reset">
			<a class="button button-secondary evatheme_core-reset-btn"><?php esc_html_e( 'Reset Settings', 'ecatheme_core' ); ?></a>
			<div class="evatheme_core-reset-checkbox"><input type="checkbox" name="evatheme_core_metabox_reset"> <?php esc_html_e( 'Are you sure? Check this box, then update your post to reset all settings.', 'ecatheme_core' ); ?></div>
		</div>

		<div class="clear"></div>

	<?php }

	/**
	 * Save metabox data
	 *
	 * @since 1.0.0
	 */
	public function save_meta_data( $post_id ) {

		// Get array of settings to save
		$tabs = evatheme_core_meta_array( get_post( $post_id ) );

		// No tabs so lets bail
		if ( ! $tabs ) {
			return;
		}

		/*
		 * We need to verify this came from our screen and with proper authorization,
		 * because the save_post action can be triggered at other times.
		 */

		// Check if our nonce is set.
		if ( ! isset( $_POST['evatheme_core_metabox_nonce'] ) ) {
			return;
		}

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( $_POST['evatheme_core_metabox_nonce'], 'evatheme_core_metabox' ) ) {
			return;
		}

		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check the user's permissions.
		if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

			if ( ! current_user_can( 'edit_page', $post_id ) ) {
				return;
			}

		} else {

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
		}

		/* OK, it's safe for us to save the data now. Now we can loop through fields */

		// Check reset field
		$reset = isset( $_POST['evatheme_core_metabox_reset'] ) ? $_POST['evatheme_core_metabox_reset'] : '';

		// Loop through tabs
		$settings = array();
		foreach( $tabs as $tab ) {
			foreach ( $tab['settings'] as $setting ) {
				$settings[] = $setting;
			}
		}

		// Loop through settings and validate
		foreach ( $settings as $setting ) {

			// Vars
			$value = '';
			$id    = $setting['id'];
			$type  = isset ( $setting['type'] ) ? $setting['type'] : 'text';

			// Make sure field exists and if so validate the data
			if ( isset( $_POST[ $id ] ) ) {

				$value = $_POST[ $id ];

				// Validate text
				if ( 'text' == $type || 'text_html' == $type ) {
					$value = wp_kses_post( $value ); // @todo change this?
				}

				// Validate textarea
				elseif ( 'textarea' == $type ) {
					$value = esc_html( $value );
				}

				// Links
				elseif ( 'link' == $type ) {
					$value = esc_url( $value );
				}

				// Validate select
				elseif ( 'select' == $type ) {
					if ( 'default' == $value ) {
						$value = '';
					} else {
						$value = wp_strip_all_tags( $value );
					}
				}

				// Validate media
				elseif ( 'media' == $type ) {

					// Move old evatheme_core_post_self_hosted_shortcode_redux to evatheme_core_post_self_hosted_media
					if ( 'evatheme_core_post_self_hosted_media' == $id && empty( $value )
						&& $old = get_post_meta( $post_id, 'evatheme_core_post_self_hosted_shortcode_redux', true )
					) {
						$value = $old;
						delete_post_meta( $post_id, 'evatheme_core_post_self_hosted_shortcode_redux' );
					}

				}

				// Validate editor
				elseif ( 'editor' == $type ) {

					$value = ( '<p><br data-mce-bogus="1"></p>' == $value ) ? '' : $value;

				}

				// Update meta if value exists
				if ( $value && 'on' != $reset ) {
					update_post_meta( $post_id, $id, $value );
				}

				// Otherwise cleanup stuff
				else {
					delete_post_meta( $post_id, $id );
				}

			}

		}

	}

}

// Start class if enabled => Filter can be used to disable class for certain users
new evatheme_core_Post_Metaboxes();