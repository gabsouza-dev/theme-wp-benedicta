<?php

class evatheme_core_welcome {
	
	function __construct() {
		add_action('wp_dashboard_setup', array($this, 'evatheme_core_dashboard_changelog'));
	}

	function evatheme_core_dashboard_changelog() {
		add_meta_box('evatheme_core_dashboard_announcement', 'Announcement by Evatheme', array($this, 'evatheme_core_dashboard_screen'), 'dashboard', 'side', 'high');
	}

	function evatheme_core_dashboard_screen() {
		?>
        
        <div id="evatheme_core-dashboard_wrap">
            <h2><?php esc_html_e( wp_get_theme()->get('Name') ) . esc_html_e( ' Help Center', 'evatheme_core' ); ?></h2>
			<div class="evatheme_core-dashboard_box">
				<p><?php esc_html_e( 'According to Envato’s terms, ', 'evatheme_core' );
				esc_html_e( wp_get_theme()->get('Name') );
				esc_html_e( ' comes with 6 months of support for every purchase, and free lifetime theme updates. This support can be extended through subscriptions via ThemeForest.', 'evatheme_core' ); ?></p>

				<p><?php esc_html_e( 'Support is limited to questions regarding the ', 'evatheme_core' );
					esc_html_e( wp_get_theme()->get('Name') .'\'s' );
					esc_html_e( ' features, or problems with the theme. To open a support ticket, please navigate to our Help Center homepage and create a topic. One of our Support Team members will respond to you shortly.', 'evatheme_core' ); ?></p>

				<p><?php esc_html_e( 'Item Support DOES include:', 'evatheme_core' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Availability of the theme\'s authors to answer questions;', 'evatheme_core' ); ?></li>
					<li><?php esc_html_e( 'Answers to technical queries about the theme\'s features;', 'evatheme_core' ); ?></li>
					<li><?php esc_html_e( 'Assistance with reported bugs and issues.', 'evatheme_core' ); ?></li>
				</ul>

				<p><?php esc_html_e( 'Item Support DOES NOT include:', 'evatheme_core' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Customization services;', 'evatheme_core' ); ?></li>
					<li><?php esc_html_e( 'Installation services;', 'evatheme_core' ); ?></li>
					<li><?php esc_html_e( 'Help and support for non-bundled third-party plugins that you install.', 'evatheme_core' ); ?></li>
				</ul>

				<a class="button button-primary" href="http://forum.evatheme.com/" target="_blank"><?php esc_html_e( 'Submit a request', 'evatheme_core' ); ?></a>
				<a class="button button-primary" href="http://<?php echo get_template(); ?>.evatheme.com/docs/" target="_blank"><?php esc_html_e( 'Documentation', 'evatheme_core' ); ?></a>

			</div>
        </div>
		
		<?php
	}
}

new evatheme_core_welcome();