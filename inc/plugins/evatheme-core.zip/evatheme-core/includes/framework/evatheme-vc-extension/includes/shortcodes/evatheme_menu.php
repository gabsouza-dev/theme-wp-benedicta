<?php
/**
 *	Menu shortcode
 */

if ( ! function_exists( 'evatheme_core_vc_menu_shortcode' ) ) {
	function evatheme_core_vc_menu_shortcode( $atts, $description_text ) {
		
		$atts = vc_map_get_attributes( 'evatheme_core_vc_menu', $atts );
		extract( $atts );

		wp_enqueue_style( 'evatheme_core-element-menu' );

		$menu_item = '';
		
		$unique_id = uniqid('menu_item_id');
		$el_class .= $unique_id .' ';
		if ( isset( $align ) && !empty( $align ) ) {
			$el_class .= $align .' ';
		}
		if ( isset( $align_type4 ) && !empty( $align_type4 ) ) {
			$el_class .= $align_type4 .' ';
		}

		$menu_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $menu_css, ' ' ), "evatheme_core_vc_menu", $atts );
		
		$img = apply_filters('ult_get_img_single', $menu_image, 'url', $img_size);

		$link = '';
		if( ( 'off' != $link_switch ) && ( !empty( $menu_link ) ) ) {
			$href = vc_build_link($menu_link);

			$url 			= ( isset( $href['url'] ) && $href['url'] !== '' ) ? $href['url']  : '';
			$target 		= ( isset( $href['target'] ) && $href['target'] !== '' ) ? esc_attr( trim( $href['target'] ) ) : '';
			$url_title 		= ( isset( $href['title'] ) && $href['title'] !== '' ) ? esc_attr($href['title']) : '';
			$rel 			= ( isset( $href['rel'] ) && $href['rel'] !== '' ) ? esc_attr($href['rel']) : '';

	        $link = '<a '. Ultimate_VC_Addons::uavc_link_init($url, $target, $url_title, $rel ).' style="color:'. $title_color .';">';
		}

		$el_class .= 'type'. $type .' ';
		
		if ( !empty( $menu_image ) ) {
			$el_class .= 'with_img ';
		} else {
			$el_class .= 'no_img ';
		}
		

		/* Custom styles */
		if ( ! empty( $title_color ) ) {
			$title_styling .= 'color:'. $title_color .';';
			$line_styling .= 'border-color:'. $title_color .';';
		}
		if ( ! empty( $title_bg ) ) {
			$title_span_styling .= 'background-color:'. $title_bg .';';
			$price_styling .= 'background-color:'. $title_bg .';';
		}

		if ( ! empty( $label_color ) ) {
			$label_styling .= 'color:'. $label_color .';';
		}
		if ( ! empty( $label_bg ) ) {
			$label_styling .= 'background-color:'. $label_bg .';';
			$label_styling .= 'margin-bottom:25px;padding-left:20px;padding-right:20px;';
		}

		if ( ! empty( $ingredients_color ) ) {
			$ingredients_styling .= 'color:'. $ingredients_color .';';
		}

		if ( ! empty( $price_color ) ) {
			$price_styling .= 'color:'. $price_color .';';
		}
		if ( ! empty( $price_bg ) ) {
			$price_styling .= 'padding-left:16px;padding-right:16px;background-color:'. $price_bg .';';
		}

		
		if ( '1' == $type ) {
			
			$menu_item .= '<div class="menu_item">';
				$menu_item .= '<div class="row">';
					
					if ( !empty( $menu_image ) ) {
						$menu_item .= '<div class="col-lg-4 mb30">';
							$menu_item .= '<div class="menu_img_wrap">';
								$menu_item .= !empty( $link ) ? $link : '';
									$menu_item .= '<img src="'. $img .'" alt="'. esc_attr( $title ) .'" />';
								$menu_item .= !empty( $link ) ? '</a>': '';
							$menu_item .= '</div>';
						$menu_item .= '</div>';
					}
					
					$menu_item_col = !empty( $menu_image ) ? 'col-lg-8' : 'col-lg-12';
					$menu_item .= '<div class="'. esc_attr( $menu_item_col ) .'">';
						$menu_item .= '<div class="menu_item_content">';
							if( !empty( $label ) ) {
								$menu_item .= '<div><span class="menu_item_label" style="'. esc_attr( $label_styling ) .'">'. esc_html( $label ) .'</span></div>';
							}
							if( !empty( $title ) ) {
								$menu_item .= '<h4 class="menu_item_title" style="'. esc_attr( $title_styling ) .'">';
									$menu_item .= '<span class="menu_item_title_span" style="'. esc_attr( $title_span_styling ) .'">';
										$menu_item .= !empty( $link ) ? $link : '';
											$menu_item .= esc_html( $title );
										$menu_item .= !empty( $link ) ? '</a>' : '';
									$menu_item .= '</span>';
									if( !empty( $price ) ) {
										$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
									}
									if ( empty( $menu_image ) ) {
										$menu_item .= '<i class="line" style="'. esc_attr( $line_styling ) .'"></i>';
									}
								$menu_item .= '</h4>';
							}
							if( !empty( $ingredients ) ) {
								$menu_item .= '<p class="menu_item_ingredients" style="'. esc_attr( $ingredients_styling ) .'">'. esc_html( $ingredients ) .'</p>';
							}
						$menu_item .= '</div>';
					$menu_item .= '</div>';

				$menu_item .= '</div>';
			$menu_item .= '</div>';

		} else if ( '2' == $type ) {
			
			$menu_item .= '<div class="menu_item">';
				if( !empty( $title ) ) {
					$menu_item .= '<h4 class="menu_item_title" style="'. esc_attr( $title_styling ) .'">';
						$menu_item .= !empty( $link ) ? $link : '';
							$menu_item .= esc_html( $title );
						$menu_item .= !empty( $link ) ? '</a>' : '';
						if( !empty( $label ) ) {
							$menu_item .= '<div class="menu_item_label"><span style="'. esc_attr( $label_styling ) .'">'. esc_html( $label ) .'</span></div>';
						}
					$menu_item .= '</h4>';
				}
				if( !empty( $ingredients ) ) {
					$menu_item .= '<p class="menu_item_ingredients" style="'. esc_attr( $ingredients_styling ) .'">'. esc_html( $ingredients ) .'</p>';
				}
				if( !empty( $price ) ) {
					$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
				}
			$menu_item .= '</div>';

		} else if ( '3' == $type ) {
			
			$menu_item .= '<div class="menu_item">';
				if ( !empty( $menu_image ) ) {
					$menu_item .= '<div class="menu_img_wrap mb25">';
						$menu_item .= !empty( $link ) ? $link : '';
							$menu_item .= '<img src="'. $img .'" alt="'. esc_attr( $title ) .'" />';
						$menu_item .= !empty( $link ) ? '</a>': '';
						if( !empty( $label ) && ( 'center' == $align ) ) {
							$menu_item .= '<div class="menu_item_label"><span style="'. esc_attr( $label_styling ) .'">'. esc_html( $label ) .'</span></div>';
						}
					$menu_item .= '</div>';
				}
				if( !empty( $label ) && ( '' == $align ) ) {
					$menu_item .= '<div class="menu_item_label"><span style="'. esc_attr( $label_styling ) .'">'. esc_html( $label ) .'</span></div>';
				}
				if( !empty( $title ) ) {
					if( 'center' == $align ) {
						$menu_item .= '<h4 class="menu_item_title" style="'. esc_attr( $title_styling ) .'">';
							$menu_item .= !empty( $link ) ? $link : '';
								$menu_item .= esc_html( $title );
							$menu_item .= !empty( $link ) ? '</a>' : '';
						$menu_item .= '</h4>';
					} else {
						$menu_item .= '<h4 class="menu_item_title" style="'. esc_attr( $title_styling ) .'">';
							$menu_item .= '<span class="menu_item_title_span" style="'. esc_attr( $title_span_styling ) .'">';
								$menu_item .= !empty( $link ) ? $link : '';
									$menu_item .= esc_html( $title );
								$menu_item .= !empty( $link ) ? '</a>' : '';
							$menu_item .= '</span>';
							if( !empty( $price ) ) {
								$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
							}
							$menu_item .= '<i class="line" style="'. esc_attr( $line_styling ) .'"></i>';
						$menu_item .= '</h4>';
					}
				}

				if( !empty( $ingredients ) ) {
					$menu_item .= '<p class="menu_item_ingredients" style="'. esc_attr( $ingredients_styling ) .'">'. esc_html( $ingredients ) .'</p>';
				}
				if( !empty( $price ) && ( 'center' == $align ) ) {
					$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
				}
			$menu_item .= '</div>';

		} else if ( '4' == $type ) {
			
			$menu_item .= '<div class="menu_item">';
				if ( !empty( $menu_image ) ) {
					$menu_item .= '<div class="menu_img_wrap mb25">';
						$menu_item .= '<img src="'. $img .'" alt="'. esc_attr( $title ) .'" />';
					$menu_item .= '</div>';
				}
				if( !empty( $label ) && ( '' == $align ) ) {
					$menu_item .= '<div class="menu_item_label"><span style="'. esc_attr( $label_styling ) .'">'. esc_html( $label ) .'</span></div>';
				}
				$menu_item .= '<div class="menu_item_descr">';
					if( !empty( $title ) ) {
						$menu_item .= '<h4 class="menu_item_title" style="'. esc_attr( $title_styling ) .'">';
							$menu_item .= !empty( $link ) ? $link : '';
								$menu_item .= esc_html( $title );
							$menu_item .= !empty( $link ) ? '</a>' : '';
							$menu_item .= '<i class="line" style="'. esc_attr( $line_styling ) .'"></i>';
						$menu_item .= '</h4>';
					}
					if( !empty( $ingredients ) ) {
						$menu_item .= '<p class="menu_item_ingredients" style="'. esc_attr( $ingredients_styling ) .'">'. esc_html( $ingredients ) .'</p>';
					}
					if( !empty( $price ) && ( 'bottom' != $align_type4 ) ) {
						$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
					}
				$menu_item .= '</div>';
				if( !empty( $price ) && ( 'bottom' == $align_type4 ) ) {
					$menu_item .= '<span class="menu_item_price" style="'. esc_attr( $price_styling ) .'">'. esc_html( $price ) .'</span>';
				}
			$menu_item .= '</div>';

		}


		$output = '';

		$output .= '<div class="evatheme_core-menu-wrap '. $el_class .' '. $menu_css .'">';
			$output .= $menu_item;
		$output .= '</div>';
        
		return $output;

	}
}
add_shortcode( 'evatheme_core_vc_menu', 'evatheme_core_vc_menu_shortcode' );

if ( ! function_exists( 'evatheme_core_vc_menu_shortcode_map' ) ) {
	function evatheme_core_vc_menu_shortcode_map() {

		vc_map( array(
			'base'			=> 'evatheme_core_vc_menu',
			'name'			=> esc_html__('Food Menu', 'evatheme_core'),
			'description'	=> esc_html__('Display Food Menu List', 'evatheme_core'),
			'category'		=> esc_html__('Evatheme Modules', 'evatheme_core'),
			'icon'			=> 'cstheme-vc-icon',
			'params' => array(
				array(
					'type'        => 'dropdown',
					'class'       => '',
					'heading'     => esc_html__( 'Type', 'evatheme_core' ),
					'description' => esc_html__( 'Select a style for the food menu list', 'evatheme_core' ),
					'param_name'  => 'type',
					'value'       => array(
						esc_html__( 'Type 1 (List with / without picture)', 'evatheme_core' )  => '1',
						esc_html__( 'Type 2 (Simple list)', 'evatheme_core' )  => '2',
						esc_html__( 'Type 3 (Top Image)', 'evatheme_core' )  => '3',
						esc_html__( 'Type 4 (Background Image)', 'evatheme_core' )  => '4',
					),
					'group'       => esc_html__( 'General', 'evatheme_core' ),
				),
				array(
					'type'        => 'dropdown',
					'class'       => '',
					'heading'     => esc_html__( 'Text Alignment', 'evatheme_core' ),
					'description' => esc_html__( 'Select a style to align the text in the menu', 'evatheme_core' ),
					'param_name'  => 'align',
					'value'       => array(
						esc_html__( 'Left', 'evatheme_core' )  => '',
						esc_html__( 'Centered', 'evatheme_core' )  => 'center',
					),
					'group'       => esc_html__( 'General', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '3' ),
					),
				),
				array(
					'type'        => 'dropdown',
					'class'       => '',
					'heading'     => esc_html__( 'Text Alignment', 'evatheme_core' ),
					'description' => esc_html__( 'Select a style to align the text in the menu', 'evatheme_core' ),
					'param_name'  => 'align_type4',
					'value'       => array(
						esc_html__( 'left-sided', 'evatheme_core' )  => 'left',
						esc_html__( 'Bottom', 'evatheme_core' )  => 'bottom',
						esc_html__( 'Centered', 'evatheme_core' )  => 'center',
					),
					'group'       => esc_html__( 'General', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '4' ),
					),
				),
				array(
					'type'        => 'ult_img_single',
					'heading'     => esc_html__( 'Select Image', 'evatheme_core' ),
					'param_name'  => 'menu_image',
					'description' => '',
					'group'       => esc_html__( 'General', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '1', '3', '4' ),
					),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Image size', 'evatheme_core' ),
					'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'evatheme_core' ),
					'param_name' => 'img_size',
					'value' => 'full',
					'group'       => esc_html__( 'General', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '1', '3', '4' ),
					),
				),
				array(
					'type'        => 'ult_switch',
					'class'       => '',
					'heading'     => esc_html__( 'Custom link to staff page', 'evatheme_core' ),
					'param_name'  => 'link_switch',
					'value'       => '',
					'options'     => array(
						'on' => array(
							'label' => esc_html__( 'Add custom link to this menu item', 'evatheme_core' ),
							'on'    => esc_html__( 'Yes', 'evatheme_core' ),
							'off'   => esc_html__( 'No', 'evatheme_core' ),
						),
					),
					'description' => '',
					'dependency'  => '',
					'group'       => esc_html__( 'General', 'evatheme_core' ),
				),
				array(
					'type'        => 'vc_link',
					'class'       => '',
					'heading'     => esc_html__( 'Custom Link', 'evatheme_core' ),
					'param_name'  => 'menu_link',
					'value'       => '',
					'description' => esc_html__( 'Add link to menu', 'evatheme_core' ),
					'group'       => esc_html__( 'General', 'evatheme_core' ),
					'dependency'  => array(
						'element' => 'link_switch',
						'value' => 'on'
					),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Extra class name', 'evatheme_core' ),
					'param_name' => 'el_class',
					'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'evatheme_core' ),
					'group'       => esc_html__( 'General', 'evatheme_core' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Dish Name', 'evatheme_core' ),
					'param_name'  => 'title',
					'admin_label' => true,
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Dish Name Color', 'evatheme_core' ),
					'param_name'  => 'title_color',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Dish Name BG Color', 'evatheme_core' ),
					'description' => esc_html__( 'Select a row background color', 'evatheme_core' ),
					'param_name'  => 'title_bg',
					'value'       => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '1', '3' ),
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Price', 'evatheme_core' ),
					'param_name'  => 'price',
					'admin_label' => true,
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Price Color', 'evatheme_core' ),
					'param_name'  => 'price_color',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Price BG Color', 'evatheme_core' ),
					'param_name'  => 'price_bg',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
					'dependency'	=> array(
						'element'		=> 'type',
						'value'			=> array( '2' ),
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Ingredients', 'evatheme_core' ),
					'param_name'  => 'ingredients',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Ingredients Color', 'evatheme_core' ),
					'param_name'  => 'ingredients_color',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Label', 'evatheme_core' ),
					'param_name'  => 'label',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Label Color', 'evatheme_core' ),
					'param_name'  => 'label_color',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Label BG Color', 'evatheme_core' ),
					'param_name'  => 'label_bg',
					'value'       => '',
					'description' => '',
					'group'       => esc_html__( 'Text', 'evatheme_core' ),
				),
				array(
					'type' => 'css_editor',
					'heading' => esc_html__( 'CSS box', 'evatheme_core' ),
					'param_name' => 'menu_css',
					'group' => esc_html__( 'Design Options', 'evatheme_core' ),
				)
			) // params array
		));
	}
}
add_action( 'vc_before_init', 'evatheme_core_vc_menu_shortcode_map' );